/*
Filename: initInterrupt.c
Programmers:  Dr. Lawrence Walker
    Modified by Dalton Messmer and Dalton Callihan
Date:     4/17/2018
Purpose:  Initializes interrupts and defines the ISR
Inputs:   None
Outputs:  None
*/

#include "F2806x_Device.h"     // F2806x Headerfile Include File
#include "initFSM.h"
#include "wait.h"

__interrupt void hrcap2_isr(void);

void initInterrupt(void)
{
    // Disable interrupts globally at the CPU level:
    DINT;

    // Disable the PIE
    PieCtrlRegs.PIECTRL.bit.ENPIE = 0;

    // Clear all PIEIER registers:
    PieCtrlRegs.PIEIER1.all = 0;
    PieCtrlRegs.PIEIER2.all = 0;
    PieCtrlRegs.PIEIER3.all = 0;
    PieCtrlRegs.PIEIER4.all = 0;
    PieCtrlRegs.PIEIER5.all = 0;
    PieCtrlRegs.PIEIER6.all = 0;
    PieCtrlRegs.PIEIER7.all = 0;
    PieCtrlRegs.PIEIER8.all = 0;
    PieCtrlRegs.PIEIER9.all = 0;
    PieCtrlRegs.PIEIER10.all = 0;
    PieCtrlRegs.PIEIER11.all = 0;
    PieCtrlRegs.PIEIER12.all = 0;

    // Clear all PIEIFR registers:
    PieCtrlRegs.PIEIFR1.all = 0;
    PieCtrlRegs.PIEIFR2.all = 0;
    PieCtrlRegs.PIEIFR3.all = 0;
    PieCtrlRegs.PIEIFR4.all = 0;
    PieCtrlRegs.PIEIFR5.all = 0;
    PieCtrlRegs.PIEIFR6.all = 0;
    PieCtrlRegs.PIEIFR7.all = 0;
    PieCtrlRegs.PIEIFR8.all = 0;
    PieCtrlRegs.PIEIFR9.all = 0;
    PieCtrlRegs.PIEIFR10.all = 0;
    PieCtrlRegs.PIEIFR11.all = 0;
    PieCtrlRegs.PIEIFR12.all = 0;

    // Disable CPU interrupts INT1-14 and clear interrupt flags:
    IER = 0x0000;
    IFR = 0x0000;

    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR).
    // This will populate the entire table, even if the interrupt
    // is not used in this example.  This is useful for debug purposes.
    // The shell ISR routines are found in F2806x_DefaultIsr.c.
    // This function is found in F2806x_PieVect.c.
    InitPieVectTable();

    // Interrupts that are used in this example are re-mapped to
    // ISR functions found within this file.
    EALLOW;  // This is needed to write to EALLOW protected registers
    //PieVectTable.TINT1 = &cpu_timer1_isr;
    PieVectTable.HRCAP2_INT = &hrcap2_isr;  // Interrupt on capture peripheral runs hrcap2_isr()
    EDIS;
}

//extern StateType * Pt;  // For FSM
extern Uint16 sendNextPulse;
extern Uint16 firstRisingEdge;
Uint16 cntrFallFinal;
Uint16 cntrFallInitial;
Uint16 cntrRiseFinal;
Uint16 cntrRiseInitial;

__interrupt void hrcap2_isr(void)
{
    EALLOW;
    HRCap2Regs.HCCTL.bit.RISEINTE = 0; // Disable rising edge interrupts
    EDIS;

    cntrFallFinal = HRCap2Regs.HCCAPCNTFALL0 + 1; // Capture current high pulse width in HCCAPCLK cycles
    cntrFallInitial = HRCap2Regs.HCCAPCNTFALL1 + 1;
    cntrRiseFinal = HRCap2Regs.HCCAPCNTRISE0 + 1;
    cntrRiseInitial = HRCap2Regs.HCCAPCNTRISE1 + 1;

    if (firstRisingEdge == 0)  // Rising edge
    {
        firstRisingEdge = 1;
        EALLOW;
        HRCap2Regs.HCCTL.bit.FALLINTE = 1;
        EDIS;
    }
    else   // Falling edge
    {
        sendNextPulse=1;
    }

    EALLOW;

    HRCap2Regs.HCICLR.all = 0x001F;          // Clear all HRCAP interrupts
    HRCap2Regs.HCICLR.bit.INT=1;             // Clear HRCAP interrupt flag
    PieCtrlRegs.PIEACK.bit.ACK4=1;           // Acknowledge PIE Group 4 interrupts.

    EDIS;
}

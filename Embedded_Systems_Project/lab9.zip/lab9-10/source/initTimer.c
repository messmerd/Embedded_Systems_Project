/*
 * initTimer.c
 *
 *  Created on: Mar 11, 2017
 *      Author: Lawrence
 */
#include "F2806x_Device.h"     // F2806x Headerfile Include File

void initTimer(void)
{
    // Init. timer period: 1 second period with SYSCLKOUT = 40MHz
    CpuTimer1Regs.PRD.half.MSW = 0x0262;
    CpuTimer1Regs.PRD.half.LSW = 0x59FF;

    // Init. presclr period
    CpuTimer1Regs.TPRH.bit.TDDRH=0;
    CpuTimer1Regs.TPR.bit.TDDR=0;

    //
    CpuTimer1Regs.TCR.bit.TSS = 1;     // Timer is stopped.
    CpuTimer1Regs.TCR.bit.TRB = 1;     // Reload counter reg with period value.
    CpuTimer1Regs.TCR.bit.SOFT = 0;
    CpuTimer1Regs.TCR.bit.FREE = 0;    // Timer free run disabled.
    CpuTimer1Regs.TCR.bit.TIE = 1;     // Enable timer interrupt.

}

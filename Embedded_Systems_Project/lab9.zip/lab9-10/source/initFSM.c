/*
 * initFSM.c
 *
 *  Created on: Mar 14, 2017
 *      Author: WalkerLA
 */

#include "F2806x_Device.h"
#include "initFSM.h"

StateType fsm[3] = {
    {
        {bothLED},       // bothLED_State
        {redLED_state}
    },

    {
        {redLED},         // redLED_State
        {blueLED_state}
    },

    {
       {blueLED},        // blueLED_State
       {bothLED_state}
    }

};

StateType *Pt; // put in initFSM.h as extern


void initFSM(void)
{

    //unsigned char Input;

    Pt = bothLED_state;

    return;
}

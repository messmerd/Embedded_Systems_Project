/*
 * initGPIO.c
 *
 *  Created on: Mar 11, 2017
 *      Author: Lawrence
 */

#include "F2806x_Device.h"

void initGPIO(void)
{
    EALLOW;
    // GPIO18 ---------------------------------------------------
    GpioCtrlRegs.GPAPUD.bit.GPIO18 = 1;   // Disable pull-up
    //GpioDataRegs.GPASET.bit.GPIO18 = 1; // Latch high
    GpioCtrlRegs.GPAMUX2.bit.GPIO18 = 3;  // GPIO18 = XCLKOUT (Pin 7  )
    GpioCtrlRegs.GPADIR.bit.GPIO18 = 1;   // GPIO18 = output

    // GPIO34 ---------------------------------------------------
    GpioCtrlRegs.GPBPUD.bit.GPIO34 = 1;   // Disable pull-up on GPIO34
    GpioDataRegs.GPBSET.bit.GPIO34 = 1;   // Latch high on GPIO34
    GpioCtrlRegs.GPBMUX1.bit.GPIO34 = 0;  // GPIO34 = GPIO34  (LED D9 )
    GpioCtrlRegs.GPBDIR.bit.GPIO34 = 1;   // GPIO34 = output

    // GPIO39 ---------------------------------------------------
    GpioCtrlRegs.GPBPUD.bit.GPIO39 = 1;   // Disable pull-up
    GpioDataRegs.GPBCLEAR.bit.GPIO39 = 1;   // Latch low on GPIO39
    GpioCtrlRegs.GPBMUX1.bit.GPIO39 = 0;  // GPIO39 = GPIO39  (LED D10)
    GpioCtrlRegs.GPBDIR.bit.GPIO39 = 1;   // GPIO39 = output

    // GPIO27 ---------------------------------------------------
    GpioCtrlRegs.GPAPUD.bit.GPIO27 = 1;   // Disable pull-up
    GpioDataRegs.GPACLEAR.bit.GPIO27 = 1;   // Latch low on GPIO27
    GpioCtrlRegs.GPAMUX2.bit.GPIO27 = 0;  // GPIO27 = GPIO27
    GpioCtrlRegs.GPADIR.bit.GPIO27 = 1;   // GPIO27 = output
    EDIS;
}

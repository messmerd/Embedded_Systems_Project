/*
Filename: main.c
Programmers:  Dr. Lawrence Walker
    Modified by Dalton Messmer and Dalton Callihan
Date:     4/17/2018
Purpose:  Interacts with an ultrasonic sensor to measure distance.
Inputs:   None
Outputs:  None, though the variable 'distance' is set
*/

#include "F2806x_Device.h"
#include "initClock.h"
#include "initGPIO.h"
#include "initInterrupt.h"
#include "initHRCAP.h"
//#include "initTimer.h"
#include "watchdog.h"
#include "wait.h"
//#include "initFSM.h"

//#pragma CODE_SECTION(InitFlash, "ramfuncs");

/*
 * main.c
 */

//extern Uint32 RamfuncsRunStart;
//extern Uint32 RamfuncsLoadStart;
//extern Uint32 RamfuncsLoadSize;

//extern StateType * Pt;

// Global variables used in program

extern Uint16 cntrFallFinal;
extern Uint16 cntrFallInitial;
extern Uint16 cntrRiseFinal;
extern Uint16 cntrRiseInitial;
volatile Uint16 sendNextPulse;
volatile Uint16 firstRisingEdge;

static volatile float distance = -1.0;

void main(void) {

    // If running from flash copy RAM only functions to RAM
    //#ifdef _FLASH
    // memcpy(&RamfuncsRunStart, &RamfuncsLoadStart, (Uint32)&RamfuncsLoadSize);
    //#endif

    disableDog();    // Disable the watchdog
    initClock();     // Initialize CPU, PLL, and XCLKOUT
    initGPIO();      // Configure GPIO.

    initInterrupt(); // Initialize CPU interrupts and PIE control regs to default state.
    initHRCAP();

    while(1)
    {
        DINT;                          // Disable Global CPU interrupt
        IER &= ~M_INT4;                // Disable CPU INT4

        EALLOW;

        GpioCtrlRegs.GPAMUX2.bit.GPIO27 = 0;  // GPIO27 = GPIO27
        GpioCtrlRegs.GPADIR.bit.GPIO27 = 1;     // GPIO27 = out (pulls low)
        GpioDataRegs.GPACLEAR.bit.GPIO27 = 1;   // Latch low on GPIO27

        wait(200ul);                          // Wait 20,000us long enough for dist. sensor to settle

        GpioDataRegs.GPACLEAR.bit.GPIO27 = 1;   // Latch low on GPIO27
        GpioCtrlRegs.GPADIR.bit.GPIO27 = 1;     // GPIO27 = out (pulls low)

        wait(120);                              // Wait 50us
        GpioDataRegs.GPASET.bit.GPIO27 = 1;
        wait(12);                               // Wait 5us
        GpioDataRegs.GPACLEAR.bit.GPIO27 = 1;

        wait(120);                              // Wait 50us

        GpioCtrlRegs.GPADIR.bit.GPIO27 = 0;     // GPIO27 = in  (release high)
        GpioDataRegs.GPASET.bit.GPIO27 = 1;     // Latch high on GPIO27

        wait(1440);  // Wait 600 us blind cycle

        GpioCtrlRegs.GPAMUX2.bit.GPIO27 = 1;  // GPIO27 = HRCAP2

        HRCap2Regs.HCICLR.all = 0x001F;
        IER |= M_INT4;                    // Enable CPU INT4
        EINT;                             // Enable global CPU interrupts
        HRCap2Regs.HCCTL.bit.RISEINTE = 1; // Enable rising edge interrupts

        firstRisingEdge=0;
        sendNextPulse = 0;
        while(sendNextPulse==0);

        DINT;                          // Disable Global CPU interrupt
        IER &= ~M_INT4;                // Disable CPU INT4

        // Sets distance to the distance the object is from the sensor in inches:
        // The constant was experimentally determined:
        distance = (cntrFallFinal - cntrRiseInitial)*0.000185391;

        EDIS;

        wait(1000000);  // Wait a lit bit before measuring the distance again

    }

}

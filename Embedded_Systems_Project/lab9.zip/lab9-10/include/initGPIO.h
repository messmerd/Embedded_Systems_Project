/*
 * initGPIO.h
 *
 *  Created on: Mar 11, 2017
 *      Author: Lawrence
 */

#ifndef INITGPIO_H_
#define INITGPIO_H_

void initGPIO(void);

#endif /* INITGPIO_H_ */

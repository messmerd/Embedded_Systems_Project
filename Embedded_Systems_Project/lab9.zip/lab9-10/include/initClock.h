/*
 * initCPU.h
 *
 *  Created on: Mar 10, 2017
 *      Author: L. Walker
 */

#ifndef INITCLOCK_H_
#define INITCLOCK_H_

void initClock(void);

#endif /* INITCLOCK_H_ */

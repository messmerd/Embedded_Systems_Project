/*
 * watchdog.h
 *
 *  Created on: Mar 10, 2017
 *      Author: Lawrence
 */

#ifndef WATCHDOG_H_
#define WATCHDOG_H_

void serviceDog(void);
void disableDog(void);

#endif /* WATCHDOG_H_ */

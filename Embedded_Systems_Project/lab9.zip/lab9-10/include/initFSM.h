/*
 * initFSM.h
 *
 *  Created on: Mar 14, 2017
 *      Author: WalkerLA
 */

#ifndef INCLUDE_INITFSM_H_
#define INCLUDE_INITFSM_H_

typedef struct State StateType;

void initFSM(void);
extern StateType * Pt;

struct State {
    unsigned char Out[1];        //Output action
    struct State *Next[1]; //Next state
};

#endif /* INCLUDE_INITFSM_H_ */

#define bothLED  0x84
#define blueLED  0x80
#define redLED   0x04

#define bothLED_state   &fsm[0]   // States
#define redLED_state    &fsm[1]
#define blueLED_state   &fsm[2]

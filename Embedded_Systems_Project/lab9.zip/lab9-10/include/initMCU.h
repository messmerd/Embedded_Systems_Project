/*
 * initMCU.h
 *
 *  Created on: Feb 28, 2017
 *      Author: Lawrence
 */

#ifndef INCLUDE_INITMCU_H_
#define INCLUDE_INITMCU_H_

void initMCU(void);

#endif /* INCLUDE_INITMCU_H_ */

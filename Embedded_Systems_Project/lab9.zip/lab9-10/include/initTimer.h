/*
 * initTimer.h
 *
 *  Created on: Mar 11, 2017
 *      Author: Lawrence
 */

#ifndef INITTIMER_H_
#define INITTIMER_H_

void initTimer(void);

#endif /* INITTIMER_H_ */

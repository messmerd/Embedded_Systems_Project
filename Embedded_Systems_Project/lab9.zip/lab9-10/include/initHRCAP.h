/*
 * initHRCAP.h
 *
 *  Created on: Mar 28, 2017
 *      Author: WalkerLA
 */

#ifndef INCLUDE_INITHRCAP_H_
#define INCLUDE_INITHRCAP_H_

void initHRCAP(void);

#endif /* INCLUDE_INITHRCAP_H_ */

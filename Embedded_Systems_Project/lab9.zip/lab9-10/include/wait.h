/*
 * wait.h
 *
 *  Created on: Feb 28, 2017
 *      Author: Lawrence
 */

#ifndef INCLUDE_WAIT_H_
#define INCLUDE_WAIT_H_


void wait(long time);


#endif /* INCLUDE_WAIT_H_ */
